# 📣 Google Ads – Performance kampane

## 🎯 Cieľ
Zvýšiť konverzie pre e-shop o 30 % počas 3 mesiacov.

## 🔧 Použité nástroje
- Google Ads, Google Analytics, Looker Studio

## 📊 Výsledky
- ROI: 3.2×
- CPC znížené o 25 %
- 18 % vyššia miera konverzie ako v predchádzajúcej kampani

## 💬 Spätná väzba
> „Kampane boli výborne optimalizované, komunikácia aj reporting profesionálne spracované.“ – Klient
