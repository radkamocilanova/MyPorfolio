# 👤 O mne
Som marketingový špecialista so skúsenosťami v PPC, SEO a performance marketingu.
Zameriavam sa na merateľné výsledky, optimalizáciu nákladov a efektívne stratégie online kampaní.

## 💼 Zručnosti
- Google Ads, Facebook Meta Ads, LinkedIn Ads
- Google Analytics, Tag Manager, Looker Studio
- Content marketing, SEO, Copywriting
- Marketing automation: HubSpot, Mailchimp
- Analýza dát, Power BI, Excel

## 🎓 Certifikáty
- Google Ads Search Certification
- Meta Certified Media Planning Professional
- HubSpot Marketing Automation Certified
